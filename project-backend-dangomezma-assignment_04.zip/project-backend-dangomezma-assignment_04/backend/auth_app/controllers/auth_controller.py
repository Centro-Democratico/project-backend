from rest_framework.decorators import api_view
from rest_framework.response import Response
from auth_app.services.auth_service import AuthService

@api_view(['POST'])
def login(request):
    correo = request.data.get('correo')
    password = request.data.get('password')

    if not correo or not password:
        return Response({'message': 'Missing fields'}, status=400)

    auth_service = AuthService()
    result = auth_service.authenticate_user(correo, password)

    if result['success']:
        return Response({'message': 'Login successful'}, status=200)
    else:
        return Response({'message': 'Login failed'}, status=401)