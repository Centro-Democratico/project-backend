from django.db import models
class Ingesoft1User(models.Model):
    correo = models.EmailField(max_length=255, null=False, blank=False, unique=True)
    password_hash = models.CharField(max_length=128, null=False, blank=False)
    secret_phrase = models.CharField(max_length=255, null=False, blank=False)

    class Meta:
        db_table = 'ingesoft1_users'