import hashlib
from auth_app.repositories.user_repository import UserRepository

class AuthService:
    def __init__(self):
        self.repository = UserRepository()

    @staticmethod
    def hash_password(password):
        return hashlib.sha512(password.encode('utf-8')).hexdigest()
    
    def authenticate_user(self, correo, password):
        user = self.repository.get_user_by_email(correo)
        if user is None:
            return {success: False, message: "Usuario no encontrado"}

        password_hash = AuthService.hash_password(password)

        if password_hash != user.password_hash:
            return {success: False, message: "Contraseña incorrecta"}
        
        return {success: True, message: "Autenticación exitosa"}