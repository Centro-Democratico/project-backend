from django.db import models
from auth_app.domain.models import Ingesoft1User
# Create your models here.
